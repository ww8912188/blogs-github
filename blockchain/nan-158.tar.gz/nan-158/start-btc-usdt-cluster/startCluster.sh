bitcoind --daemon -whitelist=127.0.0.1 -addnode=127.0.0.1:8332 -connect=127.0.0.1:8332 -server -listen -port=8331 -rpcuser=btcrpc -rpcpassword=123456 -rpcallowip=0.0.0.0/24 -rpcport=8431 -regtest=1 -addresstype=legacy -datadir=/home/ubuntu/bitcoin/regtest_btc


omnicored --daemon -server -listen -port=8332 -addnode=127.0.0.1:8331 -connect=127.0.0.1:8331 -rpcuser=btcrpc -rpcpassword=123456 -rpcallowip=0.0.0.0/24 -rpcport=8432 -regtest=1 -addresstype=legacy -datadir=/home/ubuntu/bitcoin/regtest_omni -txindex
