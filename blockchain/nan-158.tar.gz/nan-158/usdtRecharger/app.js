const Koa = require('koa')
const bodyParser = require('koa-bodyparser')
const Router = require('koa-router')
const app = new Koa()
const router = new Router()
const shell = require('shelljs')

app.use(bodyParser({}))

router.get('/test', async (ctx, next) => {
    ctx.body = {success: true}
})

router.post('/recharge', async (ctx, next) => {
  let { to, value } = ctx.request.body
  let cmd = `/opt/btc-usdt/send2.sh ${to} ${value}`
  let { code, stdout, stderr } = await shell.exec(cmd, { silent: true })
  if (code === 0) ctx.body = { success: true, data: stdout }
  else ctx.body = { success: false, err: stderr }
})

app
  .use(router.routes())
  .use(router.allowedMethods())

const port = 3009
console.log(`app listening on port ${port}`)
app.listen(port)

