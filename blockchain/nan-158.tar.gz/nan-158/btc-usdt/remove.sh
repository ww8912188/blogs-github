bitcoin-cli -conf=/opt/btc-usdt/btc.conf stop
omnicore-cli -conf=/opt/btc-usdt/usdt.conf stop
pm2 delete btc-rpc usdt-rpc btc-insight-api generate-block

rm -rf /home/ubuntu/bitcoin/regtest_btc/*
rm -rf /home/ubuntu/bitcoin/regtest_omni/*
rm -rf /home/ubuntu/bitcoin/regtest_btc_insight_api/*
