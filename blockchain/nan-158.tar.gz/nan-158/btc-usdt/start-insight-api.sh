cd /opt/btc-usdt/bitcore
./node_modules/bitcore-node/bin/bitcore-node start
