AUTH="-rpcuser=btcrpc -rpcpassword=123456 -rpcport=8431 -regtest"

bitcoin-cli $AUTH sendtoaddress $1 $2
