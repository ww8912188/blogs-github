#!/usr/bin/env bash
# BTC
./send-btc.sh 

# USDT
./send.sh mkUYRLVegHRTUL39PU6vVz2KQxn246EmWj 0.12


