cd /opt/btc-usdt
bitcoind -conf=/opt/btc-usdt/btc.conf -rpcuser=btcrpc -rpcpassword=123456
