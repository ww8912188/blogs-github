cd /opt/btc-usdt
omnicored -conf=/opt/btc-usdt/usdt.conf -rpcuser=btcrpc -rpcpassword=123456
