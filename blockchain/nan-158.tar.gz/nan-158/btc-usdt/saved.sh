bitcoin-cli -rpcuser=btcrpc -rpcpassword=123456 -rpcport=8431 -regtest listaccounts

omnicore-cli -rpcuser=btcrpc -rpcpassword=123456 -rpcport=8432 -regtest getinfo


omnicore-cli -rpcuser=btcrpc -rpcpassword=123456 -rpcport=8432 -regtest omni_sendissuancefixed $address 1 2 0 "yugaCategory" "yugaSubcategory" "yuga" "yugasun.com" "yuga for test" "100000"
