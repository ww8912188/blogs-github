btc-usdt
https://medium.com/@idhww/start-regtest-mode-network-cluster-between-bitcoin-and-omnilayer-usdt-41b53ebc3613

BTC docker
https://github.com/hunterlong/btcregtest-insight

USDT docker
https://github.com/yugasun/omnilayer-start-kit

https://github.com/OmniLayer/omnicore/blob/master/src/omnicore/doc/rpc-api.md#omni_sendissuancefixed
